"""
╔══════════════════════════════════════════════════════╗
║       STUDENT RECORD MANAGEMENT SYSTEM               ║
║       Project 1 — Python CLI Application             ║
╚══════════════════════════════════════════════════════╝

Concepts Covered:
  - Python data structures (list, dict)
  - File handling (CSV read/write)
  - Basic CRUD operations
  - Functions and modular programming
"""

import csv
import os

# ─────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────
DATA_FILE = "students.csv"
FIELDNAMES = ["id", "name", "age", "subjects", "marks"]


# ─────────────────────────────────────────────
#  FILE HANDLING — load & save
# ─────────────────────────────────────────────

def load_students():
    """Read all student records from the CSV file.

    Returns:
        list[dict]: A list of student dictionaries.
    """
    students = []
    if not os.path.exists(DATA_FILE):
        return students  # Return empty list if file doesn't exist yet

    with open(DATA_FILE, "r", newline="") as file:
        reader = csv.DictReader(file)
        for row in reader:
            # Convert 'marks' from stored string back to a list of floats
            row["marks"] = [float(m) for m in row["marks"].split("|") if m]
            # Convert 'subjects' from stored string back to a list
            row["subjects"] = row["subjects"].split("|") if row["subjects"] else []
            row["age"] = int(row["age"])
            students.append(row)

    return students


def save_students(students):
    """Write all student records to the CSV file.

    Args:
        students (list[dict]): The list of student dictionaries to save.
    """
    with open(DATA_FILE, "w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        writer.writeheader()
        for student in students:
            # Serialize lists as pipe-separated strings for CSV storage
            row = student.copy()
            row["marks"] = "|".join(str(m) for m in student["marks"])
            row["subjects"] = "|".join(student["subjects"])
            writer.writerow(row)


# ─────────────────────────────────────────────
#  UTILITY HELPERS
# ─────────────────────────────────────────────

def generate_id(students):
    """Generate the next unique student ID.

    Args:
        students (list[dict]): Current list of students.

    Returns:
        str: A new unique ID string.
    """
    if not students:
        return "S001"
    last_id = max(int(s["id"][1:]) for s in students)
    return f"S{last_id + 1:03d}"


def find_student(students, student_id):
    """Search for a student by their ID.

    Args:
        students (list[dict]): Current list of students.
        student_id (str): The ID to search for.

    Returns:
        dict | None: The student dict if found, else None.
    """
    for student in students:
        if student["id"] == student_id.upper():
            return student
    return None


def calculate_average(marks):
    """Calculate the average of a list of marks.

    Args:
        marks (list[float]): List of numeric marks.

    Returns:
        float: The average, or 0 if the list is empty.
    """
    return sum(marks) / len(marks) if marks else 0.0


def get_grade(average):
    """Convert a numeric average into a letter grade.

    Args:
        average (float): The student's average mark.

    Returns:
        str: Letter grade (A+, A, B, C, D, or F).
    """
    if average >= 90:
        return "A+"
    elif average >= 80:
        return "A"
    elif average >= 70:
        return "B"
    elif average >= 60:
        return "C"
    elif average >= 50:
        return "D"
    else:
        return "F"


# ─────────────────────────────────────────────
#  DISPLAY HELPERS
# ─────────────────────────────────────────────

def print_header(title):
    """Print a formatted section header."""
    width = 54
    print("\n" + "═" * width)
    print(f"  {title}")
    print("═" * width)


def print_student_card(student):
    """Display a single student's full details in a card format.

    Args:
        student (dict): The student record to display.
    """
    avg = calculate_average(student["marks"])
    grade = get_grade(avg)

    print(f"""
  ┌─────────────────────────────────────────┐
  │  ID      : {student['id']:<30}│
  │  Name    : {student['name']:<30}│
  │  Age     : {student['age']:<30}│
  │  Subjects: {', '.join(student['subjects']):<30}│
  │  Marks   : {', '.join(str(m) for m in student['marks']):<30}│
  │  Average : {avg:<30.2f}│
  │  Grade   : {grade:<30}│
  └─────────────────────────────────────────┘""")


def print_all_students(students):
    """Print a summary table of all student records.

    Args:
        students (list[dict]): List of all student records.
    """
    if not students:
        print("\n  ⚠  No student records found.")
        return

    print_header("ALL STUDENT RECORDS")
    print(f"  {'ID':<6} {'Name':<20} {'Age':<5} {'Average':<10} {'Grade':<5}")
    print("  " + "─" * 48)

    for s in students:
        avg = calculate_average(s["marks"])
        grade = get_grade(avg)
        print(f"  {s['id']:<6} {s['name']:<20} {s['age']:<5} {avg:<10.2f} {grade:<5}")

    print("  " + "─" * 48)
    print(f"  Total students: {len(students)}\n")


# ─────────────────────────────────────────────
#  CRUD OPERATIONS
# ─────────────────────────────────────────────

def add_student(students):
    """Prompt the user and add a new student record.

    Args:
        students (list[dict]): Current list of students (modified in-place).
    """
    print_header("ADD NEW STUDENT")

    name = input("  Enter student name        : ").strip()
    if not name:
        print("  ✗  Name cannot be empty.")
        return

    try:
        age = int(input("  Enter age                  : "))
        if age <= 0 or age > 120:
            raise ValueError
    except ValueError:
        print("  ✗  Invalid age. Please enter a positive number.")
        return

    subjects_input = input("  Enter subjects (comma-sep) : ").strip()
    subjects = [s.strip() for s in subjects_input.split(",") if s.strip()]
    if not subjects:
        print("  ✗  At least one subject is required.")
        return

    marks = []
    for subject in subjects:
        while True:
            try:
                mark = float(input(f"  Enter marks for {subject:<15}: "))
                if not (0 <= mark <= 100):
                    raise ValueError
                marks.append(mark)
                break
            except ValueError:
                print("    Please enter a valid mark between 0 and 100.")

    new_student = {
        "id": generate_id(students),
        "name": name,
        "age": age,
        "subjects": subjects,
        "marks": marks,
    }

    students.append(new_student)
    save_students(students)

    print(f"\n  ✓  Student '{name}' added with ID {new_student['id']}.")
    print_student_card(new_student)


def view_student(students):
    """Search for and display a specific student's record.

    Args:
        students (list[dict]): Current list of students.
    """
    print_header("VIEW STUDENT")

    student_id = input("  Enter Student ID (e.g. S001): ").strip()
    student = find_student(students, student_id)

    if student:
        print_student_card(student)
    else:
        print(f"\n  ✗  No student found with ID '{student_id}'.")


def edit_student(students):
    """Edit an existing student record by ID.

    Args:
        students (list[dict]): Current list of students (modified in-place).
    """
    print_header("EDIT STUDENT")

    student_id = input("  Enter Student ID to edit: ").strip()
    student = find_student(students, student_id)

    if not student:
        print(f"\n  ✗  No student found with ID '{student_id}'.")
        return

    print("\n  Current record:")
    print_student_card(student)
    print("  (Press Enter to keep existing value)\n")

    new_name = input(f"  New name [{student['name']}]: ").strip()
    if new_name:
        student["name"] = new_name

    new_age = input(f"  New age [{student['age']}]: ").strip()
    if new_age:
        try:
            student["age"] = int(new_age)
        except ValueError:
            print("  ✗  Invalid age — keeping original.")

    new_subjects_input = input(
        f"  New subjects [{', '.join(student['subjects'])}]: "
    ).strip()
    if new_subjects_input:
        student["subjects"] = [s.strip() for s in new_subjects_input.split(",") if s.strip()]
        # Re-enter marks for new subjects
        student["marks"] = []
        for subject in student["subjects"]:
            while True:
                try:
                    mark = float(input(f"  Marks for {subject}: "))
                    if not (0 <= mark <= 100):
                        raise ValueError
                    student["marks"].append(mark)
                    break
                except ValueError:
                    print("    Enter a valid mark between 0 and 100.")
    else:
        # Allow editing existing marks individually
        update_marks = input("  Update marks? (y/n): ").strip().lower()
        if update_marks == "y":
            student["marks"] = []
            for subject in student["subjects"]:
                while True:
                    try:
                        mark = float(input(f"  Marks for {subject}: "))
                        if not (0 <= mark <= 100):
                            raise ValueError
                        student["marks"].append(mark)
                        break
                    except ValueError:
                        print("    Enter a valid mark between 0 and 100.")

    save_students(students)
    print(f"\n  ✓  Student '{student['id']}' updated successfully.")
    print_student_card(student)


def delete_student(students):
    """Delete a student record by ID after confirmation.

    Args:
        students (list[dict]): Current list of students (modified in-place).
    """
    print_header("DELETE STUDENT")

    student_id = input("  Enter Student ID to delete: ").strip()
    student = find_student(students, student_id)

    if not student:
        print(f"\n  ✗  No student found with ID '{student_id}'.")
        return

    print_student_card(student)
    confirm = input("  Are you sure you want to delete this record? (yes/no): ").strip().lower()

    if confirm == "yes":
        students.remove(student)
        save_students(students)
        print(f"\n  ✓  Student '{student['name']}' (ID: {student_id}) deleted.")
    else:
        print("\n  ✗  Deletion cancelled.")


def search_students(students):
    """Search students by name (partial, case-insensitive).

    Args:
        students (list[dict]): Current list of students.
    """
    print_header("SEARCH STUDENTS")

    query = input("  Enter name to search: ").strip().lower()
    results = [s for s in students if query in s["name"].lower()]

    if results:
        print(f"\n  Found {len(results)} result(s):")
        for s in results:
            print_student_card(s)
    else:
        print(f"\n  ✗  No students found matching '{query}'.")


def show_statistics(students):
    """Display class-wide statistics and a top-performer list.

    Args:
        students (list[dict]): Current list of students.
    """
    if not students:
        print("\n  ⚠  No data to compute statistics.")
        return

    print_header("CLASS STATISTICS")

    averages = [(s, calculate_average(s["marks"])) for s in students]
    class_avg = sum(a for _, a in averages) / len(averages)
    top = max(averages, key=lambda x: x[1])
    lowest = min(averages, key=lambda x: x[1])

    # Grade distribution
    grade_counts = {"A+": 0, "A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
    for _, avg in averages:
        grade_counts[get_grade(avg)] += 1

    print(f"\n  Total Students : {len(students)}")
    print(f"  Class Average  : {class_avg:.2f}")
    print(f"  Top Performer  : {top[0]['name']} ({top[1]:.2f})")
    print(f"  Needs Support  : {lowest[0]['name']} ({lowest[1]:.2f})")

    print("\n  Grade Distribution:")
    for grade, count in grade_counts.items():
        bar = "█" * count
        print(f"    {grade:>3}  {bar} ({count})")

    print("\n  Top 3 Performers:")
    sorted_students = sorted(averages, key=lambda x: x[1], reverse=True)
    for i, (s, avg) in enumerate(sorted_students[:3], 1):
        print(f"    {i}. {s['name']:<20} {avg:.2f}  ({get_grade(avg)})")


# ─────────────────────────────────────────────
#  MAIN MENU
# ─────────────────────────────────────────────

def show_menu():
    """Display the main navigation menu."""
    print("""
  ╔══════════════════════════════════╗
  ║   STUDENT RECORD MANAGER v1.0   ║
  ╠══════════════════════════════════╣
  ║  1. Add Student                 ║
  ║  2. View All Students           ║
  ║  3. View Student by ID          ║
  ║  4. Edit Student                ║
  ║  5. Delete Student              ║
  ║  6. Search by Name              ║
  ║  7. Class Statistics            ║
  ║  0. Exit                        ║
  ╚══════════════════════════════════╝""")


def main():
    """Entry point — run the main application loop."""
    students = load_students()

    while True:
        show_menu()
        choice = input("  Choose an option: ").strip()

        if choice == "1":
            add_student(students)
        elif choice == "2":
            print_all_students(students)
        elif choice == "3":
            view_student(students)
        elif choice == "4":
            edit_student(students)
        elif choice == "5":
            delete_student(students)
        elif choice == "6":
            search_students(students)
        elif choice == "7":
            show_statistics(students)
        elif choice == "0":
            print("\n  Goodbye! Data saved to students.csv\n")
            break
        else:
            print("\n  ✗  Invalid option. Please choose 0–7.")


# ─────────────────────────────────────────────
#  SCRIPT ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    main()
