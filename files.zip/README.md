# 📚 Student Record Management System
### Python CLI Project — Project 1

---

## 🚀 How to Run

```bash
python student_manager.py
```

No external libraries needed — uses Python's built-in `csv` and `os` modules only.

---

## 📂 File Structure

```
student_management/
├── student_manager.py   ← Main application (run this)
├── students.csv         ← Auto-created data file
└── README.md            ← This file
```

---

## ✨ Features

| Feature             | Description                                    |
|---------------------|------------------------------------------------|
| **Add Student**     | Enter name, age, subjects and marks per subject|
| **View All**        | Table with ID, name, average and grade         |
| **View by ID**      | Full detail card for one student               |
| **Edit Student**    | Update any field; re-enter marks if needed     |
| **Delete Student**  | Confirm before removal                         |
| **Search by Name**  | Partial, case-insensitive name search          |
| **Statistics**      | Class average, top performers, grade chart     |

---

## 🧠 Concepts Practised

### 1. Python Data Structures
```python
student = {
    "id": "S001",
    "name": "Ananya Sharma",
    "age": 17,
    "subjects": ["Math", "Physics", "Chemistry"],
    "marks": [88, 76, 82]
}
students = [student, ...]  # list of dicts
```

### 2. File Handling (CSV)
```python
import csv

# Reading
with open("students.csv", "r") as file:
    reader = csv.DictReader(file)
    for row in reader: ...

# Writing
with open("students.csv", "w") as file:
    writer = csv.DictWriter(file, fieldnames=[...])
    writer.writeheader()
    writer.writerows(data)
```

### 3. CRUD Operations
- **C**reate → `add_student()`
- **R**ead   → `view_student()`, `print_all_students()`
- **U**pdate → `edit_student()`
- **D**elete → `delete_student()`

### 4. Modular Functions
Each feature is its own function with a clear single responsibility:
- `load_students()` / `save_students()` — file I/O
- `find_student()` — search logic
- `calculate_average()` / `get_grade()` — computation
- `generate_id()` — ID management

---

## 🎓 Grading Scale

| Average | Grade |
|---------|-------|
| ≥ 90    | A+    |
| ≥ 80    | A     |
| ≥ 70    | B     |
| ≥ 60    | C     |
| ≥ 50    | D     |
| < 50    | F     |

---

## 💡 Extension Ideas (once comfortable)
- Add a `export_report()` function that writes a PDF
- Add input validation using `try/except` more broadly
- Sort students by average when viewing all
- Add a "top N students" filter
- Load/save using JSON instead of CSV
